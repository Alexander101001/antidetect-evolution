#!/bin/bash
# Ensure Tor is running
if ! curl --socks5-hostname 127.0.0.1:9050 -s --max-time 5 https://check.torproject.org/api/ip > /dev/null 2>&1; then
    echo "🧅 Starting Tor..."
    tor --quiet &
    sleep 10
fi
echo "✅ Tor ready"

proot-distro login ubuntu -- bash -c '
cd /data/data/com.termux/files/home/.pi/skills/antidetect-stack/lib
export PYTHONIOENCODING=utf-8
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
python3 master_worker.py
'
