#!/bin/bash
# ═══════════════════════════════════════════════════════════
# AUTONOMOUS ENTERPRISE DAEMON
# Runs all systems in continuous loop
# ═══════════════════════════════════════════════════════════

cd /data/data/com.termux/files/home/.pi/skills/antidetect-stack/lib

LOG_DIR="/data/data/com.termux/files/home/.pi/skills/antidetect-stack/data/daemon_logs"
mkdir -p "$LOG_DIR"

CYCLE_COUNT=0

echo "╔══════════════════════════════════════════════════════════╗"
echo "║  🧬 AUTONOMOUS ENTERPRISE DAEMON STARTED                ║"
echo "║  📅 $(date '+%Y-%m-%d %H:%M:%S')                                  ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

while true; do
    CYCLE_COUNT=$((CYCLE_COUNT + 1))
    LOG_FILE="$LOG_DIR/cycle_${CYCLE_COUNT}_$(date +%Y%m%d_%H%M%S).log"

    echo "═══════════════════════════════════════════════════════════"
    echo "🔄 CYCLE #$CYCLE_COUNT — $(date '+%Y-%m-%d %H:%M:%S')"
    echo "═══════════════════════════════════════════════════════════"

    # 1. Run evolution cycle (highest priority)
    echo "🧬 Phase 1: Evolution cycle..."
    python3 evolution_engine.py --mode=cycle 2>&1 | tee -a "$LOG_FILE" | tail -20

    sleep 30

    # 2. Scan opportunities (every cycle)
    echo ""
    echo "📡 Phase 2: Opportunity scan..."
    python3 auto_applier.py 2>&1 | tee -a "$LOG_FILE" | tail -10

    sleep 30

    # 3. Generate affiliate content (every 3rd cycle)
    if [ $((CYCLE_COUNT % 3)) -eq 0 ]; then
        echo ""
        echo "💰 Phase 3: Affiliate content generation..."
        python3 -c "
import sys
sys.path.insert(0, '.')
import affiliate_promoter as ap
ap.AffiliatePromoter.research_product = lambda self, p: {'program': p, 'details': ap.AFFILIATE_PROGRAMS[p], 'research': ''}
promoter = ap.AffiliatePromoter()
for prog in ['Bluehost', 'Hostinger', 'ClickBank']:
    content = promoter.generate_article(prog)
    promoter.save_content(content)
print('✅ Content generated')
" 2>&1 | tee -a "$LOG_FILE" | tail -5
    fi

    sleep 60

    # Wait before next cycle (30 minutes)
    echo ""
    echo "⏳ Cycle complete. Sleeping 30 minutes..."
    echo "   Next cycle at: $(date -d '+30 minutes' '+%Y-%m-%d %H:%M:%S')"
    echo ""
    sleep 1800
done
