#!/bin/bash
# DAILY ROUTINE — Run all money-making scripts in sequence
# This is what you should run EVERY DAY to maximize earnings

echo "╔══════════════════════════════════════════════════════════╗"
echo "║  💰 DAILY MONEY ROUTINE — Maximize Your Earnings        ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "Date: $(date)"
echo ""

# 1. Generate job proposals (5 min)
echo "═══ STEP 1: GENERATE JOB PROPOSALS ═══"
cd /data/data/com.termux/files/home/.pi/skills/antidetect-stack/lib
python3 auto_applier.py 2>&1 | tail -30

echo ""
echo "═══ STEP 2: GENERATE AFFILIATE CONTENT ═══"
echo ""
echo "Now generating affiliate articles..."

# 2. Generate affiliate content
python3 -c "
import sys
sys.path.insert(0, '/data/data/com.termux/files/home/.pi/skills/antidetect-stack/lib')
import affiliate_promoter as ap
ap.AffiliatePromoter.research_product = lambda self, p: {'program': p, 'details': ap.AFFILIATE_PROGRAMS[p], 'research': ''}
promoter = ap.AffiliatePromoter()
for program in ['Bluehost', 'Hostinger', 'ClickBank']:
    content = promoter.generate_article(program)
    promoter.save_content(content)
print('✅ Affiliate content generated')
" 2>&1 | tail -10

echo ""
echo "═══ STEP 3: SHOW TODAY'S INCOME PROJECTION ═══"
echo ""
python3 /data/data/com.termux/files/home/.pi/skills/antidetect-stack/lib/earnings_tracker.py 2>&1 | tail -30

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  📊 TODAY'S OUTPUT SUMMARY                             ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "📨 Job Proposals: $(ls /data/data/com.termux/files/home/.pi/skills/antidetect-stack/data/applications/ | wc -l) files"
echo "📝 Affiliate Articles: $(ls /data/data/com.termux/files/home/.pi/skills/antidetect-stack/data/affiliate_content/*_article_*.md 2>/dev/null | wc -l) files"
echo "💼 Registered Accounts: $(python3 -c 'import json; print(len(json.load(open(\"/data/data/com.termux/files/home/.pi/skills/antidetect-stack/data/accounts/vault.json\"))))')"
echo ""
echo "✅ Daily routine complete!"
echo ""
echo "📋 NEXT STEPS (MANUAL):"
echo "   1. Open proposals in data/applications/"
echo "   2. Customize them for each job"
echo "   3. Submit on Upwork/Freelancer/Fiverr"
echo "   4. Publish affiliate articles on Medium/Dev.to"
echo "   5. Post social media updates"
echo ""
echo "⏰ Time to do this: 30-60 minutes"
echo "💵 Potential earnings: \$50-500 if you apply well"
