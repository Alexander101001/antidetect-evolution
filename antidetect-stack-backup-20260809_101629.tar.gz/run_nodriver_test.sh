#!/bin/bash
proot-distro login ubuntu -- bash -c '
cd /data/data/com.termux/files/home/.pi/skills/antidetect-stack/lib
export PYTHONIOENCODING=utf-8
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
python3 nodriver_runner.py
'
